"""
PyTorch version: U-Net style heat-map landmark network (14 landmarks).

!! NOT RUN IN THE ENVIRONMENT THAT PRODUCED THIS REPO (PyTorch could not be installed there). !!
!! It was only syntax-checked. Run the smoke test at the bottom first: `python unet_heatmap.py` !!

Why heat-maps?  Direct regression (the NumPy model) is simple, but heat-map regression is the
standard, more accurate choice for landmark localisation.  Each landmark gets a Gaussian target
map; the network predicts K maps; the landmark is the soft-argmax of its map.

Usage (training on one labelled image with augmentation):
    python torch_version/unet_heatmap.py --image data/mural_face.jpg \
        --labels data/mural_landmarks.json --passes A B C --crop mural --epochs 40
"""
import argparse, json, sys, os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rajaraja_mb.data import CROPS, load_gray, load_labels, batch   # noqa: E402

K = 14


def block(cin, cout):
    return nn.Sequential(nn.Conv2d(cin, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
                         nn.Conv2d(cout, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))


class UNetHeatmap(nn.Module):
    """Input 1x64x64 -> K heat-maps of 64x64."""

    def __init__(self, k=K, w=16):
        super().__init__()
        self.e1, self.e2, self.e3, self.e4 = block(1, w), block(w, 2 * w), block(2 * w, 4 * w), block(4 * w, 8 * w)
        self.d3, self.d2, self.d1 = block(8 * w + 4 * w, 4 * w), block(4 * w + 2 * w, 2 * w), block(2 * w + w, w)
        self.head = nn.Conv2d(w, k, 1)

    def forward(self, x):
        e1 = self.e1(x)
        e2 = self.e2(F.max_pool2d(e1, 2))
        e3 = self.e3(F.max_pool2d(e2, 2))
        e4 = self.e4(F.max_pool2d(e3, 2))
        d3 = self.d3(torch.cat([F.interpolate(e4, scale_factor=2), e3], 1))
        d2 = self.d2(torch.cat([F.interpolate(d3, scale_factor=2), e2], 1))
        d1 = self.d1(torch.cat([F.interpolate(d2, scale_factor=2), e1], 1))
        return self.head(d1)                                             # B,K,64,64


def gaussian_maps(pts_norm, size=64, sigma=2.0):
    """pts_norm: (B, 2K) in [0,1] -> (B,K,size,size) Gaussian targets; NaN landmarks give all-zero maps."""
    B = pts_norm.shape[0]
    p = pts_norm.view(B, -1, 2) * size
    ys, xs = torch.meshgrid(torch.arange(size, device=p.device), torch.arange(size, device=p.device), indexing="ij")
    d2 = (xs[None, None] - p[..., 0, None, None]) ** 2 + (ys[None, None] - p[..., 1, None, None]) ** 2
    m = torch.exp(-d2 / (2 * sigma ** 2))
    return torch.nan_to_num(m, nan=0.0)


def soft_argmax(logits, beta=1.0):
    """(B,K,H,W) -> (B,2K) normalised coordinates via spatial softmax (differentiable)."""
    B, k, H, W = logits.shape
    p = F.softmax(beta * logits.view(B, k, -1), -1).view(B, k, H, W)
    xs = (torch.arange(W, device=logits.device).float() + 0.5) / W
    ys = (torch.arange(H, device=logits.device).float() + 0.5) / H
    x = (p.sum(2) * xs).sum(-1)
    y = (p.sum(3) * ys).sum(-1)
    return torch.stack([x, y], -1).view(B, -1)


def train(args):
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    img = load_gray(args.image)
    pts = load_labels(args.labels, args.passes)
    box = CROPS[args.crop]
    net = UNetHeatmap().to(dev)
    opt = torch.optim.AdamW(net.parameters(), 2e-3, weight_decay=1e-4)
    steps = args.epochs * 100
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, 4e-3, total_steps=steps)
    rng = np.random.default_rng(0)
    for it in range(steps):
        x, y = batch(img, pts, box, 32, rng)
        x, y = torch.from_numpy(x).to(dev), torch.from_numpy(y).to(dev)
        logits = net(x)
        mask = ~torch.isnan(y.view(y.shape[0], -1, 2)[..., 0])
        loss_hm = ((torch.sigmoid(logits) - gaussian_maps(y)) ** 2).mean()                 # heat-map MSE
        coords = soft_argmax(logits).view(y.shape[0], -1, 2)
        loss_co = F.smooth_l1_loss(coords[mask], y.view(y.shape[0], -1, 2)[mask], beta=0.02)  # coordinate loss
        loss = 50 * loss_hm + loss_co
        opt.zero_grad(); loss.backward(); opt.step(); sched.step()
        if it % 100 == 0:
            print(f"step {it:5d} loss {loss.item():.4f}")
    torch.save(net.state_dict(), args.out)


if __name__ == "__main__":
    if len(sys.argv) == 1:                                               # smoke test
        net = UNetHeatmap()
        x = torch.randn(2, 1, 64, 64)
        out = net(x)
        assert out.shape == (2, K, 64, 64), out.shape
        c = soft_argmax(out)
        assert c.shape == (2, 2 * K)
        t = torch.rand(2, 2 * K)
        t[0, 3] = float("nan")
        g = gaussian_maps(t)
        assert g.shape == (2, K, 64, 64) and torch.isfinite(g).all()
        print("smoke test OK, parameters:", sum(p.numel() for p in net.parameters()))
    else:
        ap = argparse.ArgumentParser()
        ap.add_argument("--image", required=True); ap.add_argument("--labels", required=True)
        ap.add_argument("--passes", nargs="+", required=True); ap.add_argument("--crop", choices=list(CROPS), required=True)
        ap.add_argument("--epochs", type=int, default=40); ap.add_argument("--out", default="unet_heatmap.pt")
        train(ap.parse_args())
