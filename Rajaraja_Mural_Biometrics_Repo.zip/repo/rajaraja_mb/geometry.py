"""Facial proportion indices, angles, and bootstrap intervals (same formulas as the paper)."""
import numpy as np
from .data import KEYS

IDX = {k: i for i, k in enumerate(KEYS)}


def d(P, a, b):
    return np.linalg.norm(P[..., IDX[a], :] - P[..., IDX[b], :], axis=-1)


def indices(P):
    """P: (..., 14, 2) landmark array -> dict of proportion indices."""
    fh = d(P, "trichion", "menton")
    low = d(P, "subnasale", "menton")
    return {
        "upper_third/fh": d(P, "trichion", "glabella") / fh,
        "middle_third/fh": d(P, "glabella", "subnasale") / fh,
        "lower_third/fh": low / fh,
        "nose_length/fh": d(P, "nasion", "subnasale") / fh,
        "mouth_chin/lower": d(P, "stomion", "menton") / low,
    }


def roll_deg(P):
    a, b = P[..., IDX["exocanthion_l"], :], P[..., IDX["exocanthion_r"], :]
    ang = np.degrees(np.arctan2(-(b[..., 1] - a[..., 1]), b[..., 0] - a[..., 0]))
    return (ang + 90) % 180 - 90          # fold to [-90, 90): left/right labelling order does not matter


def bootstrap_ci(v, B=5000, seed=7):
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    rng = np.random.default_rng(seed)
    bs = rng.choice(v, (B, len(v))).mean(1)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0, float(lo), float(hi)
