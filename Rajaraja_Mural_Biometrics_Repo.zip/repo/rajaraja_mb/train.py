"""Train one LandmarkCNN on augmented crops of a single labelled image.

    python -m rajaraja_mb.train --image data/mural_face.jpg --labels data/mural_landmarks.json \
        --passes A B C --crop mural --iters 3000 --seed 0 --out results/mural_seed0.npz
"""
import argparse, time
import numpy as np
from .data import CROPS, load_gray, load_labels, batch, nme
from .nn import LandmarkCNN, wing_loss


def train(img, pts, box, iters=3000, bs=32, lr=2e-3, seed=0, log=250, width=8):
    rng = np.random.default_rng(seed)
    m = LandmarkCNN(14, seed, width)
    vx, vy = batch(img, pts, box, 256, np.random.default_rng(999))      # fixed validation set (new random augmentations)
    t0 = time.time()
    for it in range(1, iters + 1):
        cur = lr * 0.5 * (1 + np.cos(np.pi * it / iters))                # cosine schedule
        x, y = batch(img, pts, box, bs, rng)
        p = m.forward(x, train=True)
        loss, g = wing_loss(p, y)
        m.backward(g)
        m.step(cur)
        if it % log == 0 or it == iters:
            e = nme(m.predict(vx), vy)
            print(f"it {it:5d}  loss {loss:.4f}  val NME {np.mean(e):5.2f}% of face height   {time.time()-t0:5.0f}s", flush=True)
    return m


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--passes", nargs="+", required=True)
    ap.add_argument("--crop", choices=list(CROPS), required=True)
    ap.add_argument("--iters", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    img = load_gray(a.image)
    pts = load_labels(a.labels, a.passes)
    m = train(img, pts, CROPS[a.crop], a.iters, seed=a.seed)
    np.savez(a.out, **m.state())
    print("saved", a.out)
