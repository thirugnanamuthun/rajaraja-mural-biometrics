"""Evaluate trained ensembles and run the facial measurements.

    python -m rajaraja_mb.evaluate           (after training; see README)

Three things are reported for each source image S (mural, portrait) and the other image T:
  1. in-distribution error  : NME on fresh random augmentations of S      (the network was trained on S)
  2. cross-image error      : NME on T's canonical crop, vs. T's manual labels (never seen in training)
  3. proportion indices     : from network landmarks (ensemble + test-time augmentation) vs. manual labels
NME = mean landmark error as % of face height (trichion-menton).
"""
import glob, json, os
import numpy as np
import cv2
from .data import CROPS, KEYS, SIZE, load_gray, load_labels, batch, nme, render, crop_matrix, apply_pts
from .nn import LandmarkCNN
from .geometry import indices, roll_deg, bootstrap_ci

IMGS = {"mural": ("data/mural_face.jpg", "data/mural_landmarks.json", ["A", "B", "C"]),
        "portrait": ("data/portrait_gemini.jpg", "data/portrait_landmarks.json", ["A", "C"])}


def load_ensemble(prefix, rdir="results"):
    nets = []
    for f in sorted(glob.glob(f"{rdir}/{prefix}_seed*.npz")):
        m = LandmarkCNN(14, 0)
        m.load_state(np.load(f))
        nets.append(m)
    if not nets:
        raise SystemExit(f"no trained models found for '{prefix}' in {rdir}/ - run training first")
    return nets


def predict_image_pts(nets, img, box, n_tta=0, seed=123):
    """Landmarks in IMAGE pixel coordinates.  With n_tta>0, average predictions made on randomly
    rotated / scaled / shifted crops after mapping them back through the inverse affine transform.
    Returns array (n_nets, n_views, 14, 2)."""
    rng = np.random.default_rng(seed)
    Ms = [crop_matrix(box)] + [crop_matrix(box, rng.uniform(-10, 10), 1 + rng.uniform(-.08, .08),
                                           rng.uniform(-.04, .04), rng.uniform(-.04, .04)) for _ in range(n_tta)]
    xs = []
    for M in Ms:
        c = cv2.warpAffine(img, M, (SIZE, SIZE), flags=cv2.INTER_AREA, borderMode=cv2.BORDER_REFLECT).astype(np.float32) / 255
        xs.append(((c - c.mean()) / (c.std() + 1e-6))[None])
    X = np.stack(xs).astype(np.float32)
    out = np.zeros((len(nets), len(Ms), 14, 2))
    for i, net in enumerate(nets):
        P = net.predict(X).reshape(len(Ms), 14, 2) * SIZE
        for j, M in enumerate(Ms):
            Mi = cv2.invertAffineTransform(M)
            out[i, j] = apply_pts(Mi, P[j])
    return out


def mirror(img, pts, box):
    """Horizontally flip an image, its landmarks and its crop box.
    The portrait faces the opposite way to the mural (near eye on the left instead of the right),
    so the cross-image test mirrors the target to give both images the same pose."""
    W = img.shape[1]
    q = pts.copy()
    q[:, 0] = W - 1 - q[:, 0]
    x0, y0, x1, y1 = box
    return cv2.flip(img, 1), q, (W - x1, y0, W - x0, y1)


def main(rdir="results", n_tta=24):
    res = {}
    for src, tgt in (("mural", "portrait"), ("portrait", "mural")):
        nets = load_ensemble(src, rdir)
        simg, slab, sp = IMGS[src]; timg, tlab, tp = IMGS[tgt]
        S_img, S_pts = load_gray(simg), load_labels(slab, sp)
        T_img, T_pts = load_gray(timg), load_labels(tlab, tp)
        T_box = CROPS[tgt]
        T_img, T_pts, T_box = mirror(T_img, T_pts, T_box)           # same pose as the training image
        # 1. in-distribution error (fresh augmentations, two difficulty levels)
        r = {"n_models": len(nets)}
        for name, st in (("aug_normal", 1.0), ("aug_hard", 1.6)):
            x, y = batch(S_img, S_pts, CROPS[src], 300, np.random.default_rng(2024), st)
            r[f"in_dist_NME_{name}"] = float(np.mean([nme(n.predict(x), y).mean() for n in nets]))
        # 2. cross-image error
        for tag, k in (("plain", 0), (f"tta{n_tta}", n_tta)):
            P = predict_image_pts(nets, T_img, T_box, k)                    # nets, views, 14, 2
            pm = np.median(P.reshape(-1, 14, 2), 0)
            fh = np.linalg.norm(T_pts[0] - T_pts[7])
            per = np.linalg.norm(pm - T_pts, axis=-1) / fh * 100
            r[f"cross_NME_{tag}"] = float(np.nanmean(per))
            r[f"cross_per_landmark_{tag}"] = {k_: float(v) for k_, v in zip(KEYS, per)}
            if k:
                r["_pred_T"] = pm.tolist()
                r["_T"] = (T_img, T_pts, T_box)
                # 3. proportion indices (network, ensemble + TTA) vs manual
                per_model = np.stack([np.median(P[i], 0) for i in range(len(nets))])
                ind_net = {kk: bootstrap_ci(v) for kk, v in indices(per_model).items()}
                ind_man = {kk: float(v) for kk, v in indices(T_pts).items()}
                r["indices_network_on_target"] = {kk: dict(mean=v[0], sd=v[1], ci95=[v[2], v[3]], manual=ind_man[kk],
                                                           abs_rel_dev_pct=abs(v[0] - ind_man[kk]) / ind_man[kk] * 100)
                                                  for kk, v in ind_net.items()}
                r["roll_deg_network"] = float(np.median(roll_deg(per_model)))
                r["roll_deg_manual"] = float(roll_deg(T_pts))
        res[f"train_{src}__test_{tgt}"] = r
    os.makedirs(rdir, exist_ok=True)
    out = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")} for k, v in res.items()}
    json.dump(out, open(f"{rdir}/evaluation.json", "w"), indent=2)
    # overlay figure
    for key, r in res.items():
        tgt = key.split("__test_")[1]
        T_img, man, T_box = r["_T"]
        img = cv2.cvtColor(T_img, cv2.COLOR_GRAY2BGR)
        for (x, y), (px, py) in zip(man, np.array(r["_pred_T"])):
            if np.isfinite(x):
                cv2.circle(img, (int(x), int(y)), 7, (0, 220, 255), -1)      # manual: yellow
            cv2.circle(img, (int(px), int(py)), 7, (255, 60, 120), 2)        # network: ring
            if np.isfinite(x):
                cv2.line(img, (int(x), int(y)), (int(px), int(py)), (255, 255, 255), 1)
        x0, y0, x1, y1 = T_box
        cv2.imwrite(f"{rdir}/overlay_{key}.jpg", img[y0:y1, x0:x1])
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if not isinstance(vv, dict)} for k, v in out.items()}, indent=2))
    return out


if __name__ == "__main__":
    main()
