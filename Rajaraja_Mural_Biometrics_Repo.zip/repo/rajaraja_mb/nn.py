"""
A small convolutional neural network written from scratch in NumPy
(forward pass, manual back-propagation, Adam, Wing loss).

It exists so the whole deep-learning pipeline can be run and inspected with
nothing but NumPy.  The PyTorch version in ../torch_version does the same job
with a standard framework.
"""
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view


# --------------------------------------------------------------------- layers
class Conv3x3:
    """3x3 convolution, stride 1, 'same' padding.  x: (B, C, H, W)."""

    def __init__(self, cin, cout, rng):
        self.W = rng.normal(0, np.sqrt(2.0 / (cin * 9)), (cin * 9, cout)).astype(np.float32)  # He init
        self.b = np.zeros(cout, np.float32)
        self.dW, self.db = np.zeros_like(self.W), np.zeros_like(self.b)
        self.cin, self.cout = cin, cout

    def forward(self, x):
        B, C, H, Wd = x.shape
        xp = np.pad(x, ((0, 0), (0, 0), (1, 1), (1, 1)))
        win = sliding_window_view(xp, (3, 3), axis=(2, 3))          # B,C,H,W,3,3
        cols = win.transpose(0, 2, 3, 1, 4, 5).reshape(B * H * Wd, C * 9)
        self.cache = (cols, x.shape)
        out = cols @ self.W + self.b                                  # B*H*W, F
        return out.reshape(B, H, Wd, self.cout).transpose(0, 3, 1, 2)

    def backward(self, dout):
        cols, (B, C, H, Wd) = self.cache
        d = dout.transpose(0, 2, 3, 1).reshape(B * H * Wd, self.cout)
        self.dW = cols.T @ d
        self.db = d.sum(0)
        dcols = (d @ self.W.T).reshape(B, H, Wd, C, 3, 3)
        dxp = np.zeros((B, C, H + 2, Wd + 2), np.float32)
        for i in range(3):
            for j in range(3):
                dxp[:, :, i:i + H, j:j + Wd] += dcols[:, :, :, :, i, j].transpose(0, 3, 1, 2)
        return dxp[:, :, 1:-1, 1:-1]

    def params(self):
        return [(self.W, self.dW), (self.b, self.db)]


class ReLU:
    def forward(self, x):
        self.m = x > 0
        return x * self.m

    def backward(self, d):
        return d * self.m

    def params(self):
        return []


class MaxPool2:
    def forward(self, x):
        B, C, H, W = x.shape
        xr = x.reshape(B, C, H // 2, 2, W // 2, 2).transpose(0, 1, 2, 4, 3, 5).reshape(B, C, H // 2, W // 2, 4)
        self.arg = xr.argmax(-1)
        self.shape = x.shape
        return xr.max(-1)

    def backward(self, d):
        B, C, H, W = self.shape
        g = np.zeros((B, C, H // 2, W // 2, 4), np.float32)
        np.put_along_axis(g, self.arg[..., None], d[..., None], -1)
        return g.reshape(B, C, H // 2, W // 2, 2, 2).transpose(0, 1, 2, 4, 3, 5).reshape(B, C, H, W)

    def params(self):
        return []


class Flatten:
    def forward(self, x):
        self.s = x.shape
        return x.reshape(x.shape[0], -1)

    def backward(self, d):
        return d.reshape(self.s)

    def params(self):
        return []


class Dense:
    def __init__(self, nin, nout, rng, he=True):
        scale = np.sqrt((2.0 if he else 1.0) / nin)
        self.W = rng.normal(0, scale, (nin, nout)).astype(np.float32)
        self.b = np.zeros(nout, np.float32)
        self.dW, self.db = np.zeros_like(self.W), np.zeros_like(self.b)

    def forward(self, x):
        self.x = x
        return x @ self.W + self.b

    def backward(self, d):
        self.dW = self.x.T @ d
        self.db = d.sum(0)
        return d @ self.W.T

    def params(self):
        return [(self.W, self.dW), (self.b, self.db)]


class Dropout:
    def __init__(self, p, rng):
        self.p, self.rng, self.train = p, rng, True

    def forward(self, x):
        if not self.train or self.p == 0:
            self.m = None
            return x
        self.m = (self.rng.random(x.shape) > self.p).astype(np.float32) / (1 - self.p)
        return x * self.m

    def backward(self, d):
        return d if self.m is None else d * self.m

    def params(self):
        return []


# ----------------------------------------------------------------------- loss
def wing_loss(pred, target, w=0.10, eps=0.02):
    """Wing loss (Feng et al., CVPR 2018) on normalised coordinates.
    Returns (mean loss, gradient wrt pred).  Missing targets are NaN and ignored."""
    mask = ~np.isnan(target)
    diff = np.where(mask, pred - np.nan_to_num(target), 0.0)
    a = np.abs(diff)
    C = w - w * np.log(1 + w / eps)
    small = a < w
    loss = np.where(small, w * np.log(1 + a / eps), a - C) * mask
    grad = np.where(small, w / (eps + a), 1.0) * np.sign(diff) * mask
    n = max(mask.sum(), 1)
    return loss.sum() / n, (grad / n).astype(np.float32)


# ---------------------------------------------------------------------- model
class LandmarkCNN:
    """64x64 grey crop -> 2K normalised landmark coordinates in [0,1]."""

    def __init__(self, n_points=14, seed=0, width=8, dropout=0.2):
        rng = np.random.default_rng(seed)
        w = width
        self.drop = Dropout(dropout, rng)
        self.layers = [
            Conv3x3(1, w, rng), ReLU(), MaxPool2(),           # 64 -> 32
            Conv3x3(w, 2 * w, rng), ReLU(), MaxPool2(),       # 32 -> 16
            Conv3x3(2 * w, 4 * w, rng), ReLU(), MaxPool2(),   # 16 -> 8
            Flatten(), Dense(4 * w * 8 * 8, 128, rng), ReLU(), self.drop,
            Dense(128, 2 * n_points, rng, he=False),
        ]
        self.n_points = n_points
        self.opt_state = None

    def forward(self, x, train=True):
        self.drop.train = train
        for l in self.layers:
            x = l.forward(x)
        return x

    def backward(self, d):
        for l in reversed(self.layers):
            d = l.backward(d)

    def parameters(self):
        return [p for l in self.layers for p in l.params()]

    # Adam with decoupled weight decay (AdamW)
    def step(self, lr, wd=1e-4, b1=0.9, b2=0.999, eps=1e-8):
        ps = self.parameters()
        if self.opt_state is None:
            self.opt_state = [(np.zeros_like(p), np.zeros_like(p)) for p, _ in ps]
            self.t = 0
        self.t += 1
        for (p, g), (m, v) in zip(ps, self.opt_state):
            m *= b1; m += (1 - b1) * g
            v *= b2; v += (1 - b2) * g * g
            mh = m / (1 - b1 ** self.t)
            vh = v / (1 - b2 ** self.t)
            p -= lr * (mh / (np.sqrt(vh) + eps) + wd * p)

    def predict(self, x):
        return self.forward(x, train=False)

    def state(self):
        return {f"p{i}": p for i, (p, _) in enumerate(self.parameters())}

    def load_state(self, d):
        for i, (p, _) in enumerate(self.parameters()):
            p[...] = d[f"p{i}"]
