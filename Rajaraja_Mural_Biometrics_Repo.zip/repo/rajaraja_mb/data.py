"""Landmark labels, crops and on-the-fly augmentation."""
import json
import numpy as np
import cv2

# 14 landmarks used by the network (tragion is usually hidden and is dropped)
KEYS = ["trichion", "glabella", "nasion", "pronasale", "subnasale", "stomion", "labiale_inf", "menton",
        "endocanthion_r", "exocanthion_r", "endocanthion_l", "exocanthion_l", "cheek_r", "cheek_l"]
SIZE = 64

# Square crops (x0, y0, x1, y1) in image pixels that contain the whole face.
CROPS = {
    "mural": (40, 240, 720, 920),
    "portrait": (326, 564, 1026, 1264),
}


def load_labels(path, passes):
    """Mean of the available estimates for every landmark -> (14,2) array (NaN if absent)."""
    J = json.load(open(path))
    out = np.full((len(KEYS), 2), np.nan)
    for i, k in enumerate(KEYS):
        v = [J[p][k] for p in passes if J[p].get(k)]
        if v:
            out[i] = np.mean(v, 0)
    return out


def load_gray(path):
    im = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if im is None:
        raise FileNotFoundError(path)
    return im


def crop_matrix(box, angle=0.0, scale=1.0, tx=0.0, ty=0.0, size=SIZE):
    """2x3 affine matrix mapping image pixels -> SIZE x SIZE crop with a random similarity transform."""
    x0, y0, x1, y1 = box
    cx, cy = (x0 + x1) / 2 + tx * (x1 - x0), (y0 + y1) / 2 + ty * (y1 - y0)
    s = size / (x1 - x0) * scale
    R = cv2.getRotationMatrix2D((cx, cy), angle, s)
    R[0, 2] += size / 2 - cx
    R[1, 2] += size / 2 - cy
    return R


def apply_pts(M, pts):
    p = np.c_[pts, np.ones(len(pts))] @ M.T
    return p


def render(img, pts, box, rng=None, strength=1.0):
    """Return (crop float32 in [0,1] of shape 1xSxS, normalised targets (28,)).
    With rng given, apply random rotation / scale / shift / contrast / blur / noise."""
    if rng is None:
        M = crop_matrix(box)
    else:
        M = crop_matrix(box, rng.uniform(-15, 15) * strength, 1 + rng.uniform(-.12, .12) * strength,
                        rng.uniform(-.06, .06) * strength, rng.uniform(-.06, .06) * strength)
    c = cv2.warpAffine(img, M, (SIZE, SIZE), flags=cv2.INTER_AREA, borderMode=cv2.BORDER_REFLECT).astype(np.float32) / 255
    if rng is not None:
        c = (c - c.mean()) * rng.uniform(.7, 1.4) + c.mean() + rng.uniform(-.12, .12)      # contrast / brightness
        if rng.random() < .4:
            c = cv2.GaussianBlur(c, (3, 3), rng.uniform(.4, 1.0))
        c = c + rng.normal(0, rng.uniform(0, .04), c.shape).astype(np.float32)             # noise
        c = np.clip(c, 0, 1)
    c = (c - c.mean()) / (c.std() + 1e-6)                                                   # per-image standardisation
    t = apply_pts(M, pts) / SIZE
    return c[None].astype(np.float32), t.reshape(-1).astype(np.float32)


def batch(img, pts, box, n, rng, strength=1.0):
    xs, ys = zip(*[render(img, pts, box, rng, strength) for _ in range(n)])
    return np.stack(xs), np.stack(ys)


def face_height_norm(t):
    """Face height (trichion-menton) in normalised units for each row of targets (N,28)."""
    p = t.reshape(len(t), -1, 2)
    return np.linalg.norm(p[:, 0] - p[:, 7], axis=-1)


def nme(pred, target):
    """Normalised mean error: mean landmark distance / face height (in %), per sample."""
    p, t = pred.reshape(len(pred), -1, 2), target.reshape(len(target), -1, 2)
    d = np.linalg.norm(p - t, axis=-1)
    return 100 * np.nanmean(d, 1) / face_height_norm(target)
