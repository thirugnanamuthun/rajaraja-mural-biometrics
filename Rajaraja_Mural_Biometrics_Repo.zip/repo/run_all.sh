#!/usr/bin/env bash
# Train 3 seeds per source image, then evaluate.  ~5 min per network on one CPU core.
set -e
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p results
for s in 0 1 2; do
  python -m rajaraja_mb.train --image data/mural_face.jpg --labels data/mural_landmarks.json \
      --passes A B C --crop mural --iters 3000 --seed $s --out results/mural_seed$s.npz | tee results/train_mural_seed$s.log
  python -m rajaraja_mb.train --image data/portrait_gemini.jpg --labels data/portrait_landmarks.json \
      --passes A C --crop portrait --iters 3000 --seed $s --out results/portrait_seed$s.npz | tee results/train_portrait_seed$s.log
done
python -m rajaraja_mb.evaluate
