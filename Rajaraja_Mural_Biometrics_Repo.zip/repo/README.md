# Rajaraja Chola I — Mural Biometrics (landmark CNN)

Code behind the paper *"Digital Resurrection of Sivapadasekhara Rajaraja Chola I: Landmark-Based Mural
Measurements and Generative-AI Facial Reconstruction"* (N. Thirugnanamuthu).

The repo contains a **convolutional neural network written from scratch in NumPy** (forward pass, manual
back-propagation, AdamW, Wing loss) that learns to place 14 craniofacial landmarks on a face crop, plus the
geometry (proportion indices, head roll, bootstrap intervals) used in the paper.
A heat-map **PyTorch U-Net** is included in `torch_version/` (see status below).

## What was run, and what was not

| Part | Status |
|---|---|
| `rajaraja_mb/nn.py` NumPy CNN | Trained and evaluated. Gradients checked against finite differences (relative error 1.6e-4). `python tests/test_nn.py` |
| `rajaraja_mb/data.py`, `geometry.py`, `train.py`, `evaluate.py` | Run end to end (6 networks, 3 seeds per source image) |
| `torch_version/unet_heatmap.py` | **Not run.** PyTorch could not be installed where this repo was built; the file was only syntax-checked. Run its smoke test first. |

## Data

Labels (`data/*_landmarks.json`) are **manual landmark estimates** on two images: the mural face (3 estimates) and the
Gemini-generated portrait (2 estimates). The images themselves are not required to be public: copy your own files to
`data/mural_face.jpg` (face crop, ~1130 px, as used in the paper) and `data/portrait_gemini.jpg`.
Check the licence/provenance of the mural photograph before publishing it.

Landmarks are labelled **near eye / far eye** (`_r` / `_l`), not viewer-left/right. The portrait is the mirror
image of the mural in pose, so the cross-image test mirrors the target image first (`evaluate.mirror`).

## Method

* Input: 64x64 grey crop, per-image standardised. Output: 14 (x, y) pairs in [0, 1].
* Network: 3x [Conv3x3 -> ReLU -> MaxPool] (8, 16, 32 filters) -> Dense 128 -> Dropout 0.2 -> Dense 28 (271,772 parameters).
* Loss: Wing loss `w ln(1 + |x|/eps)` for `|x| < w`, else `|x| - C`, with `w = 0.10`, `eps = 0.02`.
* Optimiser: AdamW, cosine learning-rate schedule, 3000 iterations, batch 32.
* Data: only **one labelled image per network**, expanded on the fly by random rotation (+-15 deg), scale (+-12 %), shift,
  contrast/brightness, blur and noise, with landmarks transformed accordingly.
* Metric: NME = mean landmark error as a percentage of face height (trichion to menton).
* Inference: ensemble of 3 seeds, test-time augmentation (24 random views mapped back with the inverse affine transform), median.
* Indices: `upper/middle/lower third / face height`, `nose length / face height`, `mouth-chin / lower third`, head roll;
  bootstrap 95 % interval over the ensemble (percentile, B = 5000).

## Results (from `results/evaluation.json`)

| Train on | In-distribution NME (fresh augmentations) | Hard augmentations | Cross-image NME (other image, never seen) |
|---|---|---|---|
| mural (3 seeds) | 1.74 % | 4.37 % | 6.9 % |
| portrait (3 seeds) | 1.86 % | 4.26 % | 8.0 % |

Proportion indices predicted on the *other* image, against that image's manual labels:

| Index | mural-trained net on portrait | portrait manual | portrait-trained net on mural | mural manual |
|---|---|---|---|---|
| upper third / H | 0.245 | 0.246 | 0.249 | 0.245 |
| middle third / H | 0.459 | 0.387 | 0.389 | 0.458 |
| lower third / H | 0.299 | 0.374 | 0.371 | 0.300 |
| nose length / H | 0.323 | 0.331 | 0.333 | 0.323 |
| mouth-chin / lower | 0.765 | 0.760 | 0.768 | 0.765 |

## Read this before citing the numbers

With a single labelled image per network, the network is **a learned face-layout prior, not a measuring instrument**.
The table shows it: the mural-trained net returns the *mural's* middle and lower thirds (0.459 / 0.299) when shown the
portrait, and the portrait-trained net returns the *portrait's* (0.389 / 0.371) when shown the mural. Its landmark error
on a new image (7-8 % of face height) is of the same size as the real differences between the two faces. It therefore
cannot be used to validate or refute the manual measurements. Likewise its head-roll output follows the training pose
(8.3 deg for the portrait, whose manual roll is 0.9 deg).

What would make it a real measurement tool: tens to hundreds of independently labelled faces (painted and sculpted),
labels from more than one annotator, and a held-out set of images, not augmentations of a training image.
The code is written so that extending `data.py` to a multi-image dataset is the main change needed.

## Run

```bash
pip install -r requirements.txt
python tests/test_nn.py          # gradient check + overfit test
./run_all.sh                     # trains 6 networks (~30 min on one core) and evaluates
```
Outputs: `results/evaluation.json`, `results/overlay_*.jpg` (yellow = manual, rings = network, lines = error).

## Licence
Not set. Add one (for example MIT) before making the repository public.
