"""Run with:  python -m pytest -q   (or just  python tests/test_nn.py)"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rajaraja_mb.nn import LandmarkCNN, wing_loss


def test_gradients_match_finite_differences():
    m = LandmarkCNN(n_points=3, seed=1, width=2, dropout=0.0)
    for l in m.layers:
        for a in ("W", "b", "dW", "db"):
            if hasattr(l, a):
                setattr(l, a, getattr(l, a).astype(np.float64))
    rng = np.random.default_rng(0)
    x = rng.normal(size=(2, 1, 64, 64)); y = rng.random((2, 6)); y[0, 1] = np.nan
    loss = lambda: wing_loss(m.forward(x, True), y)[0]
    _, g = wing_loss(m.forward(x, True), y)
    m.backward(g.astype(np.float64))
    worst = 0.0
    for P, G in m.parameters():
        for _ in range(4):
            ix = tuple(rng.integers(0, s) for s in P.shape)
            old = P[ix]; h = 1e-5
            P[ix] = old + h; lp = loss(); P[ix] = old - h; lm = loss(); P[ix] = old
            num, ana = (lp - lm) / (2 * h), G[ix]
            worst = max(worst, abs(num - ana) / max(1e-8, abs(num) + abs(ana)))
    assert worst < 1e-3, worst


def test_can_overfit_a_tiny_problem():
    rng = np.random.default_rng(0)
    m = LandmarkCNN(n_points=2, seed=0, width=4, dropout=0.0)
    x = rng.normal(size=(4, 1, 64, 64)).astype(np.float32); y = rng.random((4, 4)).astype(np.float32)
    first = wing_loss(m.forward(x), y)[0]
    for _ in range(150):
        l, g = wing_loss(m.forward(x), y); m.backward(g); m.step(3e-3)
    assert l < 0.5 * first


if __name__ == "__main__":
    test_gradients_match_finite_differences(); test_can_overfit_a_tiny_problem(); print("tests OK")
